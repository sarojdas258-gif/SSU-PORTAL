# Sri Sri University – Campus Grievance Management System (UI prototype)

A mobile-first, responsive web interface for reporting and tracking campus problems.

## Run it
Open `index.html` in Chrome, Edge or Safari. No install or build step needed.
Or serve the folder: `npx serve .`

## Demo logins (any password)
Pick the matching role button on the login page, then use:

| Role | Email | Opens |
|---|---|---|
| Student | any other email | Home |
| Teacher | `teacher@…` or `faculty@…` | Home + PDF upload in Study Material |
| Admin | `admin@…` | Admin dashboard: complaints inbox, reply, assign |
| Technician | `tech@…` | Technician tasks |

Add `#design` to the address to show the screen-picker bar used for design review.

## Folder map
- `index.html` – page structure, login and screen templates
- `css/style.css` – brand colours (maroon #7A1F2B, gold #C9A24D), layout, animations
- `js/script.js` – screens, role login, complaints inbox, activities, study material
- `images/` – university logo, campus building banner, login background

## Deploy
Drag this folder onto https://app.netlify.com/drop, or push to GitHub and import it in Vercel or GitHub Pages.

## Important
This is a front-end prototype. Login, roles and data are simulated in the browser and reset on refresh.
For the real system use Next.js + Supabase: Supabase Auth, a `profiles` table with roles, row-level security on every table, and private Storage buckets for PDFs and photos.
